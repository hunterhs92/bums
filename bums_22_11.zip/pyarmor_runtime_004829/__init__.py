# Pyarmor 9.0.5 (basic), 004829, 2024-11-22T18:42:15.210112
from .pyarmor_runtime import __pyarmor__
