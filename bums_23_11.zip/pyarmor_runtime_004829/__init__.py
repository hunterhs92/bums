# Pyarmor 9.0.5 (basic), 004829, 2024-11-23T19:51:52.311016
from .pyarmor_runtime import __pyarmor__
